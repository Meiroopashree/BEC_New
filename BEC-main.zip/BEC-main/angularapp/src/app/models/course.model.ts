export class Course {
  // userId: string;
  courseID: number;
  courseName: string;
  description: string;
  duration: string;
  cost: number;
}
