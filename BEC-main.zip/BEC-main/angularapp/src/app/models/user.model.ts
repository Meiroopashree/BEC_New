export class User {
    id: number;
    emailID: string;
    password: string;
    userName: string;
    mobileNumber: string;
    userRole: string;
}